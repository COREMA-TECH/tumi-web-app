const baseEndpointURL = 'http://ec2-3-16-143-115.us-east-2.compute.amazonaws.com:4000';
//const baseEndpointURL = 'https://corema-new-api.herokuapp.com';
//const baseEndpointURL = 'https://tumicerti.herokuapp.com';
//const baseEndpointURL = 'http://ec2-18-221-184-184.us-east-2.compute.amazonaws.com:4001';
// const baseEndpointURL = 'http://localhost:5000';


export const connection = baseEndpointURL;
