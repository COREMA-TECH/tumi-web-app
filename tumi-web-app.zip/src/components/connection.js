const url = {
    cert: 'http://ec2-3-16-143-115.us-east-2.compute.amazonaws.com:4000',
    dev: 'http://ec2-3-16-143-115.us-east-2.compute.amazonaws.com:5000',
    prod: 'http://tumiapi.us-east-1.elasticbeanstalk.com',
    local: 'http://localhost:5000'
}

export const connection = url['local'];