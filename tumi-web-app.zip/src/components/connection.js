const url = {
    cert: 'http://tumiapi-12-6-2019.us-east-1.elasticbeanstalk.com',
    dev: 'http://orion-dev-api.us-east-2.elasticbeanstalk.com',
    prod: 'http://tumiapi.us-east-1.elasticbeanstalk.com',
    local: 'http://localhost:4000'
}

export const connection = url['prod'];