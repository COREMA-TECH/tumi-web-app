const url = {
    cert: 'http://tumi-cert-1.us-east-2.elasticbeanstalk.com',
    dev: 'http://ec2-3-16-143-115.us-east-2.compute.amazonaws.com:5000',
    prod: 'http://tumiapi.us-east-1.elasticbeanstalk.com',
    local: 'http://localhost:4000'
}

export const connection = url['cert'];