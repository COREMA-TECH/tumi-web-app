import Catalogs from './Catalogs';

export default Catalogs;
