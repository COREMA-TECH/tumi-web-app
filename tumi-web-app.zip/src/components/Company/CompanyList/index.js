import CompanyList from './CompanyList';

export default CompanyList;
