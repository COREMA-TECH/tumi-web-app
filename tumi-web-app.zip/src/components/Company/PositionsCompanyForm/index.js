import PositionsCompanyForm from './PositionsCompanyForm';

export default PositionsCompanyForm;
