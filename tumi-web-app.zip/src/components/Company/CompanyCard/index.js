import CompanyCard from './CompanyCard';

export default CompanyCard;
