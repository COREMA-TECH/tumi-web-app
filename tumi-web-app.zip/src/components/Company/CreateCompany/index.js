import CreateCompany from './CreateCompany';

export default CreateCompany;