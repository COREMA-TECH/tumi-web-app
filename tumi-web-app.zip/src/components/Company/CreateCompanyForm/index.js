import CreateCompanyForm from './CreateCompanyForm';

export default CreateCompanyForm;