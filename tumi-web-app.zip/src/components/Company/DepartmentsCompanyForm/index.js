import DepartmentsCompanyForm from './DepartmentsCompanyForm';

export default DepartmentsCompanyForm;
