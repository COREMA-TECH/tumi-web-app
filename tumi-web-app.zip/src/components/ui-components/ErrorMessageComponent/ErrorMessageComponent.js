import React, { Component } from 'react';
import './index.css';

class ErrorMessageComponent extends Component {
	render() {
		return (
			<div className="Error-container">
				<div className="row">

				</div>
			</div>
		);
	}
}

export default ErrorMessageComponent;