import Avatar from './Avatar';

export default Avatar;