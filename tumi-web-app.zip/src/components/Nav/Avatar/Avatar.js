import React from 'react';
import './index.css';

const Avatar = (props) => <img className="avatar" src="https://avatars3.githubusercontent.com/u/13529689?s=460&v=4"/>;

Avatar.propTypes = {};

export default Avatar;
