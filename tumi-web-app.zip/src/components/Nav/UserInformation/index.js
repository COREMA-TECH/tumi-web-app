import UserInformation from './UserInformation';

export default UserInformation;