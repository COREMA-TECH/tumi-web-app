import React, {Component} from 'react';
import './index.css';

const UserInformation = (props) => <p className="user-information">Lauren Steven Montenegro</p>;

export default UserInformation;
