import React, {Component} from 'react';

class IndependentContract extends Component {
    render() {
        return (
            <div className="Apply-container--application">
                <div className="row"></div>
            </div>
        );
    }
}

export default IndependentContract;