import React, { Component } from 'react';
import './index.css';
import { gql } from 'apollo-boost';
import withApollo from 'react-apollo/withApollo';
import LinearProgress from '@material-ui/core/LinearProgress/LinearProgress';
import ApplicationTable from './ApplicationTable';
import { Query } from 'react-apollo';
import NothingToDisplay from 'ui-components/NothingToDisplay/NothingToDisplay';
import withGlobalContent from 'Generic/Global';
import ErrorMessageComponent from 'ui-components/ErrorMessageComponent/ErrorMessageComponent';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import AlertDialogSlide from 'Generic/AlertDialogSlide';

import makeAnimated from 'react-select/lib/animated';
import Select from 'react-select';
import { GET_PROPERTIES_QUERY, GET_DEPARTMENTS_QUERY } from './Queries';

const styles = (theme) => ({
	root: {
		flexGrow: 1
	},
	paper: {
		padding: theme.spacing.unit * 2,
		textAlign: 'center',
		color: theme.palette.text.secondary
	}
});

const DEFAULT_PROPERTY = { value: '', label: 'Property(All)' };
const DEFAULT_DEPARTMENT = { value: '', label: 'Department(All)' };

class ApplicationList extends Component {
	constructor(props) {
		super(props);

		this.state = {
			loadingContracts: false,
			data: [],
			filterText: '',
			opendialog: false,
			property: DEFAULT_PROPERTY,
			department: DEFAULT_DEPARTMENT,
			properties: [],
			departments: []
		};
	}

	/**
     * This method redirect to create application component
     */
	redirectToCreateApplication = () => {
		this.props.history.push({
			pathname: '/employment-application',
			state: { ApplicationId: 0 }
		});
	};

	GET_APPLICATION_QUERY = gql`
		query applicationsByUser($idUsers: Int,$Id_Department: Int, $idEntity: Int){
			applicationsByUser(idUsers: $idUsers, Id_Department: $Id_Department, idEntity: $idEntity) {
				id
				firstName
				middleName
				lastName
				socialSecurityNumber
				emailAddress
				cellPhone
				isLead
				idWorkOrder
            	statusCompleted
				recruiter{
					Full_Name
				}
				user{
					Full_Name
				}
				position{
					id
					position {
							Position
						}
					BusinessCompany {
							Id
							Code
							Name
						}
				}
			}
		}
	`;

	DELETE_APPLICATION_QUERY = gql`
		mutation disableApplication($id: Int!) {
			disableApplication(id: $id) {
				id
				isActive
			}
		}
	`;

	deleteApplication = () => {
		this.setState(
			{
				loadingConfirm: true
			},
			() => {
				this.props.client
					.mutate({
						mutation: this.DELETE_APPLICATION_QUERY,
						variables: {
							id: this.state.idToDelete
						}
					})
					.then((data) => {
						this.props.handleOpenSnackbar('success', 'Application Deleted!');
						this.setState({ opendialog: false, loadingConfirm: false }, () => { });
					})
					.catch((error) => {
						this.props.handleOpenSnackbar('error', 'Error: Deleting Position and Rates: ' + error);
						this.setState({
							loadingConfirm: false
						});
					});
			}
		);
	};

	onDeleteHandler = (id) => {
		this.setState({ idToDelete: id, opendialog: true });
	};
	handleCloseAlertDialog = () => {
		this.setState({ opendialog: false });
	};
	handleConfirmAlertDialog = () => {
		this.deleteApplication();
	};
	handlePropertyChange = (property) => {
		this.setState((prevState) => ({
			property,
			department: prevState.property.value != property.value ? DEFAULT_DEPARTMENT : prevState.department,
			departments: prevState.property.value != property.value ? [] : prevState.departments
		}), () => {
			this.getDepartments();
		});
	}
	handleDepartmentChange = (department) => {
		this.setState(() => ({ department }));
	}

	getProperties = () => {
		this.setState(() => ({ loadingProperties: true }), () => {
			this.props.client
				.query({
					query: GET_PROPERTIES_QUERY,
					fetchPolicy: 'no-cache'
				})
				.then(({ data }) => {
					let options = [];

					//Add first record
					options.push(DEFAULT_PROPERTY);

					//Create structure based on property data
					data.getbusinesscompanies.map((property) => {
						options.push({ value: property.Id, label: property.Code + " | " + property.Name });
					});

					//Set values to state
					this.setState(() => ({
						properties: options,
						loadingProperties: false
					}));

				})
				.catch(error => {
					this.setState(() => ({ loadingProperties: false }));
				});
		})
	}

	getDepartments = () => {
		this.setState(() => ({ loadingDepartments: true }), () => {
			var variables = {};

			if (this.state.property.value)
				variables = { Id_Entity: this.state.property.value };

			this.props.client
				.query({
					query: GET_DEPARTMENTS_QUERY,
					variables,
					fetchPolicy: 'no-cache'
				})
				.then(({ data }) => {
					let options = [];

					//Add first record
					options.push({ value: '', label: 'Department(All)' });

					//Create structure based on department data
					data.catalogitem.map(({ Id, DisplayLabel }) => {
						options.push({ value: Id, label: DisplayLabel })
					});

					this.setState(() => ({
						departments: options,
						loadingDepartments: false
					}));
				})
				.catch(error => {
					this.setState(() => ({ loadingDepartments: false }));
				});
		})
	}

	componentWillMount() {
		this.getProperties();
		this.getDepartments();
	}
	render() {
		var loading = this.state.loadingContracts || this.state.loadingProperties || this.state.loadingDepartments;
		var variables = {};

		/**
		 * Start - Define variables for application query
		 */
		if (localStorage.getItem('isEmployee') == 'true')
			variables = { idUsers: localStorage.getItem('LoginId') };
		if (this.state.property.value != '')
			variables = { ...variables, idEntity: this.state.property.value };
		if (this.state.department.value != '')
			variables = { ...variables, Id_Department: this.state.department.value };
		/**
		 * End - Define variables for application query
		 */

		// If contracts query is loading, show a progress component
		if (loading) {
			return <LinearProgress />;
		}

		// To render the content of the header
		let renderHeaderContent = () => (
			<div className="row pb-0">
				<div className="col-md-2">
					<div className="input-group mb-3">
						<div className="input-group-prepend">
							<span className="input-group-text" id="basic-addon1">
								<i className="fa fa-search icon" />
							</span>
						</div>
						<input
							onChange={(text) => {
								this.setState({
									filterText: text.target.value
								});
							}}
							value={this.state.filterText}
							type="text"
							placeholder="Applicant Search"
							className="form-control"
						/>
					</div>
				</div>
				<div className="col-md-1 offset-md-7">
					<Select
						name="property"
						options={this.state.properties}
						value={this.state.property}
						onChange={this.handlePropertyChange}
						components={makeAnimated()}
						closeMenuOnSelect
					/>
				</div>
				<div className="col-md-1">
					<Select
						name="department"
						options={this.state.departments}
						value={this.state.department}
						onChange={this.handleDepartmentChange}
						components={makeAnimated()}
						closeMenuOnSelect
					/>
				</div>
				<div className="col-md-1">
					<Select
						name="department"
						options={this.state.departments}
						value={this.state.department}
						onChange={this.handleDepartmentChange}
						components={makeAnimated()}
						closeMenuOnSelect
					/>
				</div>
			</div>
		);

		return (

			<div className="main-application">
				<AlertDialogSlide
					handleClose={this.handleCloseAlertDialog}
					handleConfirm={this.handleConfirmAlertDialog}
					open={this.state.opendialog}
					loadingConfirm={this.state.loadingConfirm}
					content="Do you really want to continue whit this operation?"
				/>
				<div className="">{renderHeaderContent()}</div>
				<div className="main-contract__content">
					<Query query={this.GET_APPLICATION_QUERY} variables={variables} pollInterval={300}>
						{({ loading, error, data, refetch, networkStatus }) => {
							if (this.state.filterText === '') {
								if (loading && !this.state.opendialog) return <LinearProgress />;
							}

							if (error)
								return (
									<ErrorMessageComponent
										title="Oops!"
										message={'Error loading applications'}
										type="Error-danger"
										icon="danger"
									/>
								);
							if (data.applicationsByUser != null && data.applicationsByUser.length > 0) {
								let dataApplication = data.applicationsByUser.filter((_, i) => {
									if (this.state.filterText === '') {
										return true;
									}

									if (
										(_.firstName +
											_.middleName +
											_.lastName +
											(_.position ? _.position.position.Position.trim() : 'Open Position') +
											(_.idWorkOrder ? `000000${_.idWorkOrder}`.slice(-6) : '') +
											(_.position ? _.position.BusinessCompany.Name : '') +
											(_.recruiter ? _.recruiter.Full_Name : '') +
											(_.user ? _.user.Full_Name : '') +
											_.emailAddress)
											.toLocaleLowerCase()
											.indexOf(this.state.filterText.toLocaleLowerCase()) > -1
									) {
										return true;
									}
								});

								return (
									<div className="row pt-0">
										{localStorage.getItem('isEmployee') == 'false' &&
											<div className="col-md-12">
												<button
													className="btn btn-success float-right"
													onClick={() => {
														this.redirectToCreateApplication();
													}}
												>
													Add Application
														</button>
											</div>}
										<div className="col-md-12">
											<div className="card">
												<ApplicationTable
													data={dataApplication}
													onDeleteHandler={this.onDeleteHandler}
												/>
											</div>
										</div>
									</div>
								);
							}
							return (
								<NothingToDisplay
									title="Oops!"
									message={'There are no applications'}
									type="Error-success"
									icon="wow"
								/>
							);
						}}
					</Query>
				</div>
			</div>
		);
	}
}

ApplicationList.propTypes = {
	classes: PropTypes.object.isRequired
};

export default withStyles(styles)(withApollo(withGlobalContent(ApplicationList)));
