import Search from './SearchBar';

export default Search;
