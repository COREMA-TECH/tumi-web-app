import React, {Component} from 'react';
import './index.css';

class Toolbar extends Component {
    render() {
        return (
            <div className="toolbar__main">
            </div>
        );
    }
}

export default Toolbar;
