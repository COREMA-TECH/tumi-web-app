import MainContainer from './MainContainer';

export default MainContainer;
