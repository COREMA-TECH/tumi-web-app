import React, { Component } from 'react';

class DashBoardSponsor extends Component {

    render() {
        return (
            <div>

            </div>
        );
    }

}

export default DashBoardSponsor;